import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Forras, amely generalja a vizet, amely tovabb folyik csohalozatba.
 */
public class Fountain extends Field implements Steppable{
    /**
     * referencia teszteleshez (nev amit a create fuggvenyben kapott
     */
    private  String referenceID;
    public Fountain(String refID){
        referenceID=refID;
    }
    public Fountain(){
        referenceID= UUID.randomUUID().toString();
    }
    /**
     * generalja a vizet, minden szomszedjara meghivja az AcceptWater metodust, parameterben magaval
     */
    public void GenerateWater(){
        List<Field> neighbour = Game.Get().GetMap().GetNeighbours(this);
        for(Field f: neighbour){
            if(f!=null){
                f.AcceptWater(this);
            }
        }
    }

    /**
     * @return tesztelesi referencia
     */
    public String GetReferenceID(){return referenceID;}

    /**
     * forras korvegi lepese, meghivja a GenerateWater metodust magan
     */
    public void Step(){
        GenerateWater();
    }

    /**
     * nem fogadhat vizet, visszaad false erteket
     * @param f mezo, ahonnan fogadja a vizet
     * @return elfogata e a vizet
     */
    public boolean AcceptWater(Field f){
        return false;
    }

    /**
     * kilistazza a szabotor altal elvegezheto akciokat
     * @param saboteur szabotor, aki vegzi az akciokat
     */
    public void SaboteurOptions(Saboteur saboteur){
        saboteur.ClearOptions();
        List<Field> neighbours = Game.Get().GetMap().GetNeighbours(this);
        List<Field> steppableNeighbours = new ArrayList<>();
        for(Field neighbour: neighbours){
            if(neighbour.CanAcceptPlayer())
                steppableNeighbours.add(neighbour);
        }
        if(steppableNeighbours.size() != 0)
            saboteur.AddOption("move");
    }

    /**
     * kilistazza a szerelo altal elvegezheto akciokat
     * @param fixer szerelo, aki vegzi az akciokat
     */
    public void FixerOptions(Fixer fixer){
        fixer.ClearOptions();
        List<Field> neighbours = Game.Get().GetMap().GetNeighbours(this);
        List<Field> steppableNeighbours = new ArrayList<>();
        List<Field> removableNeighbours = new ArrayList<>();
        for(Field neighbour: neighbours){
            if(neighbour.CanAcceptPlayer())
                steppableNeighbours.add(neighbour);
            if(neighbour.GetRemovable())
                removableNeighbours.add(neighbour);
        }
        if(steppableNeighbours.size() != 0)
            fixer.AddOption("move");
        if(!fixer.GetHasActive() && removableNeighbours.size() != 0)
            fixer.AddOption("remove pipe");
        if(fixer.GetHasActive() && removableNeighbours.size() != 0)
            fixer.AddOption("place active");
    }
    //todo
    public Field Update() {
        return this;
    }
}
