import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

/**
 * A pumpa feladata a viz tovabbitasa.
 * A pumpa rendelkezik egy kis tartallyal, amelyet a szallitott viz ideiglenes tarolasara hasznal.
 * Egy pumpa tobb kimenettel, illetve bemenettel is rendelkezik, de mindig egyszerre csak egy iranybol egy iranyba tud vizet pumpalni.
 * A pumpa veletlen idokozonkent elromlik, ilyenkor nem aramlik rajta keresztul a viz.
 * A szabotor jatekosok es a szerelo jatekosok is at tudjak allitani, hogy a pumpa melyik bemeneterol melyik kimenetere pumpalja tovabb a vizet.
 */
public class Pump extends Active{
    /**
     * referencia teszteleshez (nev amit a create fuggvenyben kapott)
     */
    private String referenceID;
    public Pump(){
        referenceID= UUID.randomUUID().toString();
    }
    public Pump(String refID){
        referenceID=refID;
    }
    /**
     * tarolt viz mennyiseg
     */
    private int storedWater = 0;

    public String GetReferenceID(){return referenceID;}

    /**
     * Tovabbitja a vizet
     */
    public void ForwardWater(){
        if(storedWater>0 && !GetIsBroken()){
            if(GetPOut()!=null){
                if(GetPOut().AcceptWater(this)){
                    DecreaseStoredWater();
                }
            }
        }
    }

    /**
     * csokkenti a tarolt viz mennyiseget
     */
    public void DecreaseStoredWater(){
        storedWater--;
    }

    /**
     * pumpa fogadja a vizet
     * @param f mezo, ahonnan fogadja a vizet
     * @return elfogadta e a vizet
     */
    public boolean AcceptWater(Field f){
        if(f == GetPIn() && storedWater < 5){
            IncreaseStoredWater();
            return true;
        }
        return false;
    }

    /**
     * Meghibasodik a pumpa veletlenszeru idokozonkent
     */
    public void Malfunction(){
        if(new Random().nextInt(10) == 0 || !PrototypeTester.Get().GetIsRandom()){
            SetIsBroken(true);
            PrototypeTester.Get().SetString("pump malfunctioned\n");
        }
    }


    /**
     * az adott objektum korvegi lepese, ilyenkor pumpal egyet vagy a sajat tartalyaba, vagy a kimeneti csore
     */
    public void Step(){
        Malfunction();
        ForwardWater();
    }

    /**
     * noveli a tarolt viz mennyiseget
     */
    public void IncreaseStoredWater(){storedWater++;}

    /**
     * beallitja storedWater erteket a kapottra
     * @param n tarolt vizmennyiseg
     */
    public void SetStoredWater(int n){storedWater = n;}

    /**
     * visszaadja storedWater erteket
     * @return tarolt vizmennyiseg
     */
    public int GetStoredWater(){ return storedWater;}

    /**
     * kilistazza a szabotor altal elvegezheto akciokat
     * @param saboteur aki a mezon eppen all
     */
    public void SaboteurOptions(Saboteur saboteur){
        saboteur.ClearOptions();
        List<Field> neighbours = Game.Get().GetMap().GetNeighbours(this);
        List<Field> steppableNeighbours = new ArrayList<>();
        for(Field neighbour: neighbours){
            if(neighbour.CanAcceptPlayer())
                steppableNeighbours.add(neighbour);
        }
        if(steppableNeighbours.size() != 0)
            saboteur.AddOption("move");
        saboteur.AddOption("set pump");
    }

    /**
     * kilistazza a szerelo altal elvegezheto akciokat
     * @param fixer szerelo aki rajta all
     */
    public void FixerOptions(Fixer fixer){
        fixer.ClearOptions();
        List<Field> neighbours = Game.Get().GetMap().GetNeighbours(this);
        List<Field> steppableNeighbours = new ArrayList<>();
        List<Field> removableNeighbours = new ArrayList<>();
        for(Field neighbour: neighbours){
            if(neighbour.CanAcceptPlayer())
                steppableNeighbours.add(neighbour);
            if(neighbour.GetRemovable())
                removableNeighbours.add(neighbour);
        }
        if(steppableNeighbours.size() != 0)
            fixer.AddOption("move");
        if(!fixer.GetHasActive() && removableNeighbours.size() != 0)
            fixer.AddOption("remove pipe");
        if(fixer.GetHasActive() && removableNeighbours.size() != 0)
            fixer.AddOption("place active");
        if(GetIsBroken())
            fixer.AddOption("fix");
        fixer.AddOption("set pump");
    }

    /**
     * beallitja a ki es bemeneti csoveket nullra
     * @param in be, vagy kimenetkent allitjuk be az elemet
     * @param a cso
     */
    public void SetDirection(boolean in, Field a){
        if(in && GetPIn()==a){
            SetPIn(null);
        }
        if(!in && GetPOut()==a){
            SetPOut(null);
        }
    }

    //todo

    /**
     * A pumpa allapotatol fuggoen elvegzi a kor vegi viselkedest
     * @return A kovetkezo idopontban a pumpa allapota
     */
    public Field Update() {
        Pump next = new Pump();
        next.SetPIn(GetPIn());
        next.SetPOut(GetPOut());
        next.storedWater = storedWater;
        if(storedWater < 5 && GetPIn().GetHasWater() && !GetIsBroken()){
            next.GetPIn().SetHasWater(false);
            next.storedWater++;
            next.setHasWater(true);
        }else if(storedWater >= 5){
            next.GetPIn().SetHasWater(GetPIn().GetHasWater());
        }else if(GetIsBroken()){
            next = this;
        }
        return next;
    }
}
