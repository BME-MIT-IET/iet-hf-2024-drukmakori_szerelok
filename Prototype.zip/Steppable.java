/**
 * Interfesz, amelyet megvalosito osztalyok a kor vegen frissulnek es uj allapotba lepnek.
 */
public interface Steppable {
    /**
     * amely fuggvenyt a mezok megvalositanak az ido mulasakor
     */
    void Step();
}
