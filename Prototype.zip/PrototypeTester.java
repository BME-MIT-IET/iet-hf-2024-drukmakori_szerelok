import javax.sound.midi.SysexMessage;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * A prototypetester osztalyban megy vegbe a teszteles, itt vannak megirva a tesztfuggvenyek,
 * amelyeket a bemeneti nyelvben lehet hasznalni. A parancsertelmezo fuggveny is itt szerepel,
 * amely egy sorat ertelmezi a bemeneti file-nak.
 */
public class PrototypeTester {
 private Game jatek;
 private String string="a";
 /**
  * A tesztpalya
  */
 private Map palya = null;
 /**
  * A veletlenszeru ertekek be/ki kapcsolasahoz
  */
 private boolean random = true;
 /**
  * Barhonnan elerheto peldanya az osztalynak, amelyet csak egyszer lehet letrehozni
  */
 private static PrototypeTester single_instance = null;

 /**
  * Konstruktor, beallitja a palyat
  */
 public PrototypeTester() {
  Game.Get().SetMap(palya);
 }
 public static PrototypeTester Get()
 {
  // To ensure only one instance is created
  if (single_instance == null) {
   single_instance = new PrototypeTester();
  }
  return single_instance;
 }


 public void SetString(String s){
  string=s;
 }
 public String GetString(){
  return string;
 }
 /**
  * Random valtozo getter fuggvenye
  * @return random valtozo erteke true/false
  */
 public boolean GetIsRandom(){
  return random;
 }

 /**
  * A create tesztfuggveny megvalositasa, letrehoz egy peldanyt a parameterben kapott objektumbol,
  * a parameterben kapott neven, a letrehozott peldany felkerul a terkepre is
  * @param nameOfClass A letrehozando objektum osztalya
  * @param nameOfObject A letrehozando objektum neve
  * @return Sikeres/sikertelen letrehozas eseten a visszateresi String-ben szerepel az uzenet
  */
 public String create(String nameOfClass, String nameOfObject) {
  String statusText = "";
  switch (nameOfClass) {
   case "Tank":
    Tank t = new Tank(nameOfObject);
    if (palya != null)
     palya.addField(t);

    statusText = "created:" + nameOfObject + "(Tank)\n";
    break;
   case "Map":
    palya = new Map(nameOfObject);
    Game.Get().SetMap(palya);
    statusText = "created:" + nameOfObject + "(Map)\n";
    break;
   case "Pipe":
    if (palya != null)
     palya.addField(new Pipe(nameOfObject));
    statusText = "created:" + nameOfObject + "(Pipe)\n";
    break;
   case "Fountain":
    if (palya != null)
     palya.addField(new Fountain(nameOfObject));
    statusText = "created:" + nameOfObject + "(Fountain)\n";
    break;
   case "BlankField":
    if (palya != null)
     palya.addField(new BlankField(nameOfObject));
    statusText = "created:" + nameOfObject + "(BlankField)\n";
    break;
   case "Pump":
    if (palya != null)
     palya.addField(new Pump(nameOfObject));
    statusText = "created:" + nameOfObject + "(Pump)\n";
    break;
   case "Fixer":
    Fixer fi = new Fixer(nameOfObject);
    if (palya != null){
     Game.Get().AddPlayer(fi);
    }
    statusText = "created:" + nameOfObject + "(Fixer)\n";
    break;
   case "Saboteur":
    Saboteur sa = new Saboteur(nameOfObject);
    if (palya != null){
     Game.Get().AddPlayer(sa);
    }
    statusText = "created:" + nameOfObject + "(Saboteur)\n";
    break;
  }
  if (statusText.equals("")) statusText = "creation Failed!\n";
  return statusText;
 }

 /**
  * A mozgatasert felelos tesztfuggveny, amely a parameterkent kapott jatekost a parameterkent kapott mezore
  * mozgatja.
  * @param p A mozgatando jatekos
  * @param f1 A mezo, ahova a jatekost mozgatni szeretnenk
  * @return
  */
 public String move(Player p, Field f1) {
  if(p.GetField() == null && f1.CanAcceptPlayer()){
   f1.AcceptPlayer();
   return "moved:" + p.GetReferenceID() + " " + p.GetField().GetReferenceID() + "\n" + "Action points decreased." + "\n";
  }
  else if(p.GetField() == null && !f1.CanAcceptPlayer())
   return "Moving " + p.GetReferenceID() + " was unsuccessful as the current Field(" + f1.GetReferenceID() + ") is occupied." + "\n";
  p.InteractOptions();
  List<String> temp = p.GetOptions();
  for (String s : temp) {
   if (s.contains("move") && f1.CanAcceptPlayer()) {
    for (Field f : Game.Get().GetMap().GetNeighbours(p.GetField())) {
     if (f == f1) {
      p.Move(f1);
      return "moved:" + p.GetReferenceID() + " " + p.GetField().GetReferenceID() + "\n" + "Action points decreased." + "\n";
     }
    }
   }
  }
  if(!f1.CanAcceptPlayer())
   return "Moving " + p.GetReferenceID() + " was unsuccessful as the current Field(" + f1.GetReferenceID() + ") is occupied." + "\n";
  return "Moving " + p.GetReferenceID() + " was unsuccessful." + "\n";
 }

 /**
  * Beallitja a parameterben megadott ciszternaban tarolt pumpak szamat
  * @param t a beallitando ciszterna
  * @param count a pumpak szamat mennyire allitsa
  * @return sikeressegrol/sikertelensegrol uzenet
  */
 public String set_Tank_NumberOfPumps(Tank t, int count) {
  t.setNumberOfPumps(count);
  return "NumberOfPumps:" + t.getNumberOfPumps() + "\n";
 }

 /**
  * Beallitja a parameterben megadott ciszternaban tarolt csovek szamat
  * @param t a beallitando ciszterna
  * @param count a csovek szamat mennyire allitsa
  * @return sikeressegrol/sikertelensegrol uzenet
  */
 public String set_Tank_NumberOfPipes(Tank t, int count) {
  t.setNumberOfPipes(count);
  return "NumberOfPipes:" + t.getNumberOfPipes() + "\n";
 }

 /**
  * A megadott szerelo megprobalja megjavitani a megadott pumpat
  * @param Sanyi a szerelo akivel a javitast elvegezzuk
  * @return javitas sikeressegerol/sikertelensegerol uzenet
  */
 public String fix(Fixer Sanyi) {
  Sanyi.InteractOptions();
  List<String> temp = Sanyi.GetOptions();
  for (String s : temp) {
   if (s.contains("fix")) {
    Sanyi.Fix((Active) Sanyi.GetField());
    return "Fixed:" + Sanyi.GetField().GetReferenceID() + '\n' + "Action points decreased." + "\n";
   }
  }
  return "Unable to fix " + Sanyi.GetField().GetReferenceID() + ": it's not broken." + "\n";
 }

 /**
  * A megadott szerelo megprobalja elhelyezni a megadott mezore a nala levo aktiv elemet
  * @param Sanyi A szerelo aki elhelyezze az elemet
  * @param f1 A mezo ahova el kell helyezni az elemet
  * @return Az elhelyezes sikeressegerol/sikertelensegerol uzenet
  */
 public String place(Fixer Sanyi, Field f1) {
  Sanyi.InteractOptions();
  List<String> temp = Sanyi.GetOptions();
  for (String s : temp) {
   if (s.contains("place active") && f1.GetRemovable()) {
    for (Field f : Game.Get().GetMap().GetNeighbours(Sanyi.GetField())) {
     if (f == f1) {
      Sanyi.Place(f1);
      return "Active has been placed to " + f1.GetReferenceID() + '\n' + "Action points decreased." + "\n";
     }
    }
   }
  }
  return "Unable to place Active." + "\n";
 }

 /**
  * A megadott szerelo a megadott ciszternabol pumpat vesz fel
  * @param Sanyi A szerelo, aki felveszi a pumpat
  * @param t A ciszterna, ahonnan a pumpat fel kell venni
  * @return A felvetel sikeressegerol/sikertelensegerol uzenet
  */
 public String carryPump(Fixer Sanyi, Tank t) {
  Sanyi.InteractOptions();
  List<String> temp = Sanyi.GetOptions();
  for (String s : temp) {
   if (s.contains("carry pump")) {
    Sanyi.CarryPump(t);
    return "Sanyi hasActive:" + Sanyi.GetHasActive() + '\n' + "Action points decreased." + "\n";
   }
  }
  return "Unable to carry pump." + "\n";
 }

 /**
  * A megadott szerelo a megadott ciszternabol csovet vesz fel
  * @param Sanyi A szerelo aki felveszi a pumpat
  * @param t A ciszterna, ahonnan a csovet fel kell venni
  * @return A felvetel sikeressegerol/sikertelensegerol uzenet
  */
 public String carryPipe(Fixer Sanyi, Tank t) {
  Sanyi.InteractOptions();
  List<String> temp = Sanyi.GetOptions();
  for (String s : temp) {
   if (s.contains("carry pipe")) {
    Sanyi.CarryPipe(t);
    return "Sanyi hasActive:" + Sanyi.GetHasActive() + '\n' + "Action points decreased." + "\n";
   }
  }
  return "Unable to carry pipe." + "\n";
 }

 /**
  * A parameterken megadott aktiv elem elromlik/megjavul
  * @param a Az aktiv elem amit  el kell rontani/megjavitani
  * @param b Az elem elromoljon/megjavuljon
  * @return Az elem allapotarol uzenet
  */
 public String set_IsBroken(Active a, boolean b) {
  a.SetIsBroken(b);
  return "IsBroken:" + a.GetReferenceID() + " " + a.GetIsBroken() + "\n";
 }

 /**
  * Beallitja az adott pumpaban tarolt viz mennyiseget
  * @param p1 Az allitando pumpa
  * @param count A beallitando vizmennyiseg
  * @return A pumpaban tarolt vizrol uzenet
  */
 public String set_storedWater(Pump p1, int count) {
  p1.SetStoredWater(count);
  return "pump water:" + p1.GetStoredWater() + "\n";
 }

 /**
  * A megadott szabotor megprobalja csuszossa tenni a megadott csovet
  * @param Szabi A szabotor aki csuszossa teszi a csovet
  * @param p1 A cso amit csuszossa szeretnenk tenni
  * @return A cso csuszossagarol allapotuzenet
  */
 public String makeSlippery(Saboteur Szabi, Pipe p1) {
  String tempS;
  if(p1.GetSlippery() > 0)
   tempS = "pipe slippery: true" + "\n";
  else
   tempS = "pipe slippery: false" + "\n";
  Szabi.InteractOptions();
  List<String> temp = Szabi.GetOptions();
  for (String s : temp) {
   if (Szabi.GetField() == p1 && s.contains("make slippery")) {
    Szabi.MakeSlippery(p1);
    tempS += "pipe slippery: true\nAction points decreased.\n";
    return tempS;
   }
  }
  tempS += "pipe slippery: true\n";
  return tempS;
 }

 /**
  * A megadott szabotor megprobalja kilyukasztani a megadott csovet
  * @param Szabi A szabotor, aki lyukaszt
  * @param p1 A cso, amit lyukasztani szeretnenk
  * @return Az interakcio sikeressegerol/sikertelensegerol uzenet
  */
 public String pipeSabotage(Player Szabi, Pipe p1) {
  Szabi.InteractOptions();
  List<String> temp = Szabi.GetOptions();
  for (String s : temp) {
   if (Szabi.GetField() == p1 && s.contains("sabotage pipe")) {
    Szabi.PipeSabotage(p1);
    return p1.GetReferenceID() + "'s been sabotaged by " + Szabi.GetReferenceID() + ".\nAction points decreased.\n";
   }
  }
  return "Interaction failed:" + p1.GetReferenceID() + " cannot be sabotaged for " + p1.GetUnDestroyable() + " more turn(s).\n";
 }

 /**
  * A veletlenszeru esemenyek be es kikapcsolasa
  * @param b Be, vagy kikapcsoljuk a veletlen esemenyeket
  * @return A random esemenyek be kikapcsolasarol allapotuzenet
  */
 public String random(boolean b) {
  String returnString="";
  if(PrototypeTester.Get().random) returnString="random:true\n";
  else returnString="random:false\n";
  PrototypeTester.Get().random=b;
  if(PrototypeTester.Get().random) {
   returnString+="random:true\n";
   return returnString;
  }
  returnString+="random:false\n";
  return returnString;
 }

 /**
  * A megadott jatekos ragadossa teszi a megadott csovet
  * @param Szabi A jatekos, aki ragadossa tesz
  * @param p1 A cso, amit ragadossa szeretnenk tenni
  * @return A cso ragados allapotarol allapotuzenet
  */
 public String makeSticky(Player Szabi, Pipe p1) {
  String tempS;
  if(p1.GetSticky() > 0)
   tempS = "pipe sticky: true\n";
  else
   tempS = "pipe sticky: false\n";
  Szabi.InteractOptions();
  List<String> temp = Szabi.GetOptions();
  for (String s : temp) {
   if (Szabi.GetField() == p1 && s.contains("make sticky")) {
    Szabi.MakeSticky(p1);
    tempS += "pipe sticky: true\nAction points decreased.\n";
    return tempS;
   }
  }
  tempS += "pipe sticky: true\n";
  return tempS;
 }

 /**
  * A megadott szerelo felvesz egy adott csovet a palyarol
  * @param Sanyi A szerelo, aki felveszi a csovet
  * @param p1 A cso, amit felvesznek
  * @return A felvetel sikeressegerol/sikertelensegerol uzenet
  */
 public String removeActivePipe(Fixer Sanyi, Pipe p1) {
  Sanyi.InteractOptions();
  List<String> temp = Sanyi.GetOptions();
  for (String s : temp) {
   if (s.contains("remove pipe")) {
    for (Field f : Game.Get().GetMap().GetNeighbours(Sanyi.GetField())) {
     if (f == p1) {
      Sanyi.RemoveActivePipe(p1);
      return Sanyi.GetReferenceID() + " has active: " + Sanyi.GetHasActive() + "\nAction points decreased.\n";
     }
    }
   }
  }
  return "Unable to remove pipe.\n";
 }

 /**
  * A megadott jatekos beallitja a megadott pumpa iranyat
  * @param Szabi A szerelo, aki a pumpat allitja
  * @param p1 A pumpa, amit allitunk
  * @param dir Bemenet
  * @param p2 Kimenet
  * @return A beallitas sikeressegerol/sikertelensegerol uzenet
  */
 public String set_Pump_Dir(Player Szabi, Pump p1, String dir, Pipe p2) {
  Szabi.InteractOptions();
  List<String> temp = Szabi.GetOptions();
  for (String s : temp) {
   if (s.contains("set pump") && Szabi.GetField() == p1) {
    for (Field f : Game.Get().GetMap().GetNeighbours(Szabi.GetField())) {
     if (f == p2) {
      if(Objects.equals(dir, "in")){
       Szabi.SetPump(p2, p1.GetPIn(), p1);
       return p1.GetReferenceID() + "'s in direction has been set to " + p2.GetReferenceID() + ".\nAction points decreased.\n";
      }
      else {
       Szabi.SetPump(p1.GetPIn(), p2, p1);
       return p1.GetReferenceID() + "'s out direction has been set to " + p2.GetReferenceID() + ".\nAction points decreased.\n";
      }
     }
    }
   }
  }
  return "Unable to set pump direction.\n";
 }

 /**
  * Beallitja, hogy hany potja van a szerelok csapatanak
  * @param points A beallitando pontok szama
  * @return Statuszuzenet
  */
 public String set_fixerPoints(int points){
  String returnString = "fixerPoints "+Game.Get().GetFixerPoints()+"\n"+"fixerPoints "+points+"\n";
  Game.Get().SetFixerPoints(points);
  if(Game.Get().GetGameEndMessage()!="") returnString+="The Game has already ended\n";
  else{
   Game.Get().StartGame();
   if(Game.Get().GetGameEndMessage()!="") returnString+=Game.Get().GetGameEndMessage()+"\n";
  }
  return returnString;
 }

 /**
  * Beallitja, hogy hany potja van a szerelok csapatanak
  * @param points A beallitando pontok szama
  * @return Statuszuzenet
  */
 public String set_saboteurPoints(int points){
  String returnString = "saboteurPoints "+Game.Get().GetSaboteurPoints()+"\n"+"saboteurPoints "+points+"\n";
  Game.Get().SetSaboteurPoints(points);
  if(Game.Get().GetGameEndMessage()!="") returnString+="The Game has already ended\n";
  else{
   Game.Get().StartGame();
   if(Game.Get().GetGameEndMessage()!="") returnString+=Game.Get().GetGameEndMessage()+"\n";
  }
  return returnString;
 }

 /**
  * A a kor vegi ido mulasat szimulalja, lepteti a vilagot, ilyenkor folyik peldaul a viz
  * @return Kor vegi esemeny uzenete
  */
 public String world_step(){
  Game.Get().SetMap(palya);
  String temp = "";
  int fixerPoints=Game.Get().GetFixerPoints();
  int saboteurPoints=Game.Get().GetSaboteurPoints();
  Game.Get().GetActionHandler().WorldTurn();
  if(fixerPoints!=Game.Get().GetFixerPoints()){
   temp+="Water received, point accredited to Fixers.\n";
  }
  if(saboteurPoints!=Game.Get().GetSaboteurPoints()){
    temp+="Water leaked, point accredited to Saboteurs.\n";
  }
  if(PrototypeTester.Get().GetString()!=""){
   temp+=PrototypeTester.Get().GetString();
  }
  return temp;
 }

 /**
  * A parancsertelmezo fuggveny, amely vegigmegy egy adott bemeneti szovegfile-on es elvegzi a bemeneten kapott
  * parancsokat, a kimenetuket pedig osszegyujti egy String-be es visszater vele
  * @param list A bemeneti parancsok, egy String[] egy sornak felel meg
  * @return A parancsok visszateresi ertekeit gyujti ossze
  */
 public String Test(ArrayList<String[]> list) {
  PrototypeTester.Get().random=true;
  PrototypeTester.Get().SetString("");
  Game.Get().ResetGame();
  StringBuilder output = new StringBuilder();
  for (String[] command : list) {
   String returnString = "";
   switch (command[0]) {
    case "create":
     returnString = create(command[1], command[2]);
     break;
    case "move":
     Player player = Game.Get().searchPlayer(command[1]);
     Game.Get().SetActivePlayer(player);
     Field field = palya.searchField(command[2]);
     if (player != null && field != null) returnString = move(player, field);
     if (player == null) {
      returnString = "There is no such player found: " + command[1] + "\n";
     }
     if (field == null) {
      returnString += "There is no such field found: " + command[2] + "\n";
     }
     break;
    case "set_Tank_NumberOfPumps":
     Tank tank = (Tank)palya.searchField(command[1]);
     if (tank == null) {
      returnString = "There is no such tank found: " + command[1] + "\n";
     }
     else{
      returnString = set_Tank_NumberOfPumps(tank, Integer.parseInt(command[2]));
     }
     break;
    case "set_Tank_NumberOfPipes":
     Tank tank2 = (Tank)palya.searchField(command[1]);
     if (tank2 == null) {
      returnString = "There is no such tank found: " + command[1] + "\n";
     }
     else{
      returnString = set_Tank_NumberOfPipes(tank2, Integer.parseInt(command[2]));
     }
     break;
    case "fix":
     Fixer fixer = (Fixer)Game.Get().searchPlayer(command[1]);
     Game.Get().SetActivePlayer(fixer);
     if (fixer == null) {
      returnString = "There is no such player found: " + command[1] + "\n";
     }
     else{
      returnString = fix(fixer);
     }
     break;
    case "place":
     Fixer fixer2 = (Fixer)Game.Get().searchPlayer(command[1]);
     Game.Get().SetActivePlayer(fixer2);
     Field f1 = palya.searchField(command[2]);
     if (fixer2 != null && f1 != null) returnString = place(fixer2, f1);
     if (fixer2 == null) {
      returnString = "There is no such fixer found: " + command[1] + "\n";
     }
     if (f1 == null) {
      returnString += "There is no such field found: " + command[2] + "\n";
     }
     break;
    case "set_IsBroken":
     Active a = (Active)palya.searchField(command[1]);
     if (a != null) returnString = set_IsBroken(a, Boolean.parseBoolean(command[2]));;
     if (a == null) {
      returnString = "There is no such active found: " + command[1] + "\n";
     }
     break;
    case "set_storedWater":
     Pump p = (Pump)palya.searchField(command[1]);
     if (p != null) returnString = set_storedWater(p, Integer.parseInt(command[2]));;
     if (p == null) {
      returnString = "There is no such pump found: " + command[1] + "\n";
     }
     break;
    case "makeSlippery":
     Saboteur s = (Saboteur)Game.Get().searchPlayer(command[1]);
     Game.Get().SetActivePlayer(s);
     Pipe pi = (Pipe)palya.searchField(command[2]);
     if (s != null && pi!=null) returnString = makeSlippery(s, pi);
     if (s == null) {
      returnString = "There is no such saboteur found: " + command[1] + "\n";
     }
     if (pi == null) {
      returnString += "There is no such pipe found: " + command[2] + "\n";
     }
     break;
    case "pipeSabotage":
     Player Szabi = Game.Get().searchPlayer(command[1]);
     Game.Get().SetActivePlayer(Szabi);
     Pipe pi3 = (Pipe)palya.searchField(command[2]);
     if (Szabi != null && pi3!=null) returnString = pipeSabotage(Szabi, pi3); //Szabi fieldje nincs be�ll�tva
     if (Szabi == null) {
      returnString = "There is no such player found: " + command[1] + "\n";
     }
     if (pi3 == null) {
      returnString += "There is no such pipe found: " + command[2] + "\n";
     }
     break;
    case "random":
     returnString = random(Boolean.parseBoolean(command[1]));
     break;
    case "makeSticky":
     Player pl = Game.Get().searchPlayer(command[1]);
     Game.Get().SetActivePlayer(pl);
     Pipe pi2 = (Pipe)palya.searchField(command[2]);
     if (pl != null && pi2!=null) returnString = makeSticky(pl, pi2);
     if (pl == null) {
      returnString = "There is no such player found: " + command[1] + "\n";
     }
     if (pi2 == null) {
      returnString += "There is no such pipe found: " + command[2] + "\n";
     }
     break;
    case "removeActivePipe":
     Fixer fi = (Fixer)Game.Get().searchPlayer(command[1]);
     Game.Get().SetActivePlayer(fi);
     Pipe pi4 = (Pipe)palya.searchField(command[2]);
     if (fi != null && pi4!=null) returnString = removeActivePipe(fi, pi4);
     if (fi == null) {
      returnString = "There is no such fixer found: " + command[1] + "\n";
     }
     if (pi4 == null) {
      returnString += "There is no such pipe found: " + command[2] + "\n";
     }

     break;
    case "carryPipe":
     Fixer f = (Fixer)Game.Get().searchPlayer(command[1]);
     Game.Get().SetActivePlayer(f);
     Tank t = (Tank)palya.searchField(command[2]);
     if (f != null && t != null) returnString = carryPipe(f, t);
     if (f == null) {
      returnString = "There is no such fixer found: " + command[1] + "\n";
     }
     if (t == null) {
      returnString += "There is no such tank found: " + command[2] + "\n";
     }
     break;
    case "carryPump":
     Fixer f2 = (Fixer)Game.Get().searchPlayer(command[1]);
     Game.Get().SetActivePlayer(f2);
     Tank t1 = (Tank)palya.searchField(command[2]);
     if (f2 != null && t1 != null) returnString = carryPump(f2, t1);
     if (f2 == null) {
      returnString = "There is no such fixer found: " + command[1] + "\n";
     }
     if (t1 == null) {
      returnString += "There is no such tank found: " + command[2] + "\n";
     }
     break;
    case "Set_Pump_Dir":
     Player p2 = Game.Get().searchPlayer(command[1]);
     Game.Get().SetActivePlayer(p2);
     Pump pu = (Pump)palya.searchField(command[2]);
     Pipe pi5 = (Pipe)palya.searchField(command[4]);
     if (p2 == null) {
      returnString = "There is no such player found: " + command[1] + "\n";
     }
     if (pu == null) {
      returnString += "There is no such pump found: " + command[2] + "\n";
     }
     if (pi5 == null) {
      returnString += "There is no such pipe found: " + command[4] + "\n";
     }
     if(pi5 != null && pu != null && p2 != null){
      returnString = set_Pump_Dir(p2, pu, command[3], pi5);
     }
     break;
    case "set_fixerPoints":
     returnString = set_fixerPoints(Integer.parseInt(command[1]));
     break;
    case "set_saboteurPoints":
     returnString = set_saboteurPoints(Integer.parseInt(command[1]));
     break;
    case "world_step":
     returnString = world_step();
     break;
   }
   output.append(returnString);
  }
  return output.toString();
 }
}