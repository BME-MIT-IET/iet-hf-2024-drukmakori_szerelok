import java.util.Random;
import java.util.UUID;

/**
 * A szabotor jatekos a szerelohoz hasonloan kepes mozogni a csovek halozatan.
 * Az a celja, hogy minel tobb vizet kifolyasson a sivatagba.
 * Azert, hogy ezt elerje kepes kilyukasztani meglevo csoveket,
 * vagy atallitani egy pumpat oly modon hogy az a vizet a sivatagba pumpalja egy ciszterna helyett.
 */
public class Saboteur extends Player{
    /**
     * referencia teszteleshez (nev amit a create fuggvenyben kapott)
     */
    private String referenceID;
    public Saboteur(String refID){
        referenceID=refID;
    }
    public Saboteur(){
        referenceID= UUID.randomUUID().toString();
    }

    /**
     * @return tesztelesi referencia
     */
    public String GetReferenceID(){return referenceID;}

    /**
     * csuszossa teszi a parameterul kapott csovet
     */
    public void MakeSlippery(Pipe p){
        if(PrototypeTester.Get().GetIsRandom()) p.SetSlippery(new Random().nextInt(3)+1);
        else p.SetSlippery(3);
        DecreaseActionPoints();
    }

    /**
     * Meghivja a mezo, amin all SaboteurOptions metodusat
     */
    public void InteractOptions(){
        GetField().SaboteurOptions(this);
    }
}
