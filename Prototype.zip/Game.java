import java.util.ArrayList;
import java.util.List;

/**
 * A jatek vezerleseert felelos osztaly, elinditja a jatekot,
 * vezerli a jatekosok koreit, figyeli a pontokat, es ha osszegyulnek pontok, befejezi a jatekot.
 */
public class Game implements Steppable {
    /**
     * pontszam, amit a gyozelemert el kell erni
     */
    private int pointsToWin = 100;
    /**
     * szerelok pontszama
     */
    private int fixerPoints = 0;
    /**
     * szabotorok pontszama
     */
    private int saboteurPoints = 0;
    /**
     * a palya
     */
    private Map map=null;
    /**
     * singleton game
     */
    private static Game single_instance = null;
    /**
     * jelenlegi aktiv jatekos
     */
    private Player activePlayer;
    /**
     * a jatekban szereplo jatekosok listaja
     */
    private final ArrayList<Player> players;
    /**
     * kezeli a koroket
     */
    private final ActionHandler actionHandler = new ActionHandler();
    private String gameEndMessage="";

    /**
     * jatekoslista letrehozasa
     */
    private Game(){
        players = new ArrayList<Player>();
    }

    /**
     * atadja a singleton game peldanyt
     * @return sajat maga
     */
    public static Game Get()
    {
        // To ensure only one instance is created
        if (single_instance == null) {
            single_instance = new Game();
        }
        return single_instance;
    }

    /**
     * visszaadja a jatekosok listajat
     * @return a jatekosok listaja
     */
    public List<Player> GetPlayers(){
        return players;
    }

    /**
     * beallitja a jelenlegi soron levo aktiv jatekost
     * @param p az uj aktiv jatekos
     */
    public void SetActivePlayer(Player p){
        activePlayer=p;
    }

    /**
     * elinditja a jatekot
     */
    public void StartGame(){
        while(fixerPoints < pointsToWin && saboteurPoints < pointsToWin){
            Game.Get().Step();
        }
        EndGame();
    }
    /**
     * befejezi a jatekot
     */
    public void EndGame(){
        if(fixerPoints>=100 && saboteurPoints<100){
            gameEndMessage="Game won by Fixers.";
        }
        else if(fixerPoints<100 && saboteurPoints>=100){
            gameEndMessage="Game won by Saboteurs.";
        }
        else if(fixerPoints>=100 && saboteurPoints>=100){
            gameEndMessage="Draw, game won by both teams.";
        }
    }

    /**
     * az adott objektum korvegi lepese, ez vegzi a jatek koreinek inditasat
     */
    public void Step(){
        actionHandler.HandleTurn();
    }

    /**
     * Noveli a szerelok pontjainak szamat
     */
    public void InceraseFixerPoints(){ fixerPoints++; }

    /**
     * Noveli a szabotorok ponjainak szamat
     */
    public void InceraseSaboteurPoints(){ saboteurPoints++; }

    /**
     * Visszaadja az eppen soron levo jatekost
     * @return az eppen soron levo jatekos
     */
    public Player GetActivePlayer(){ return activePlayer; }

    /**
     * Visszaadja a terkepet
     * @return a terkep
     */
    public Map GetMap(){
        return map;
    }

    /**
     * beallitja a terkepet
     * @param m ujterkep
     */
    public void SetMap(Map m){
        map=m;
    }
    /**
     * hozzaad a jatekhoz egy jatekost
     * @param p jatekos
     */
    public void AddPlayer(Player p){
        players.add(p);
    }

    /**
     * visszaadja a parameterul kapott ID-val rendelkezo jatekost
     * @param refID keresett jatekos ID-ja
     * @return keresett jatekos
     */
    public Player searchPlayer(String refID){
        Player temp=null;
        for (Player player : players) {
            if (player.GetReferenceID().equals(refID)) {
                temp = player;
            }
        }
        return temp;
    }

    /**
     * visszaadja GameEndMessage erteket
     * @return jatek vege uzenet
     */
    public String GetGameEndMessage(){
        return gameEndMessage;
    }

    /**
     * beallitja fixer csapat pontszamat a kapott ertekre
     * @param p uj pontszam
     */
    public void SetFixerPoints(int p){
        fixerPoints=p;
    }
    /**
     * beallitja saboteur csapat pontszamat a kapott ertekre
     * @param p uj pontszam
     */
    public void SetSaboteurPoints(int p){
        saboteurPoints=p;
    }
    /**
     * visszaadja fixer csapat pontszamat
     * @return fixer csapat pontszama
     */
    public int GetFixerPoints(){
        return fixerPoints;
    }
    /**
     * visszaadja saboteur csapat pontszamat
     * @return saboteur csapat pontszama
     */
    public int GetSaboteurPoints(){
        return saboteurPoints;
    }

    /**
     * reseteli a jatekot
     */
    public void ResetGame(){
        players.clear();
        saboteurPoints=0;
        fixerPoints=0;
        gameEndMessage="";
    }
    /**
     * visszaadja az actionhandlert
     * @return az actionhandler
     */
    public ActionHandler GetActionHandler(){
        return actionHandler;
    }
}
