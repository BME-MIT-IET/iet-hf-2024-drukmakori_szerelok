import javax.swing.plaf.basic.BasicLookAndFeel;
import java.util.UUID;

/**
 * Az ures sivatagi mezo, amelyen sem cso, sem pumpa, sem ciszterna, sem forras nem szerepel.
 * Ha a viz ide kifolyik, akkor a szabotorok kapnak pontot.
 */
public class BlankField extends Field{
    /**
     * referencia teszteleshez (nev amit a create fuggvenyben kapott
     */
    private String referenceID;
    /**
     * A BlankField mindig kicserelheto lesz
     */
    public BlankField(String refID){
        SetRemovable(true);
        referenceID=refID;
    }
    public BlankField(){
        SetRemovable(true);
        referenceID= UUID.randomUUID().toString();
    }

    /**
     * @return tesztelesi referencia
     */
    public String GetReferenceID(){return referenceID;}

    /**
     * A mezo fogadja a rafolyo vizet.
     * @param f mezo, ahonnan folyik a viz
     * @return a mezo tudta-e fogadni a vizet
     */
    public boolean AcceptWater(Field f){ return false; }
    /**
     * Az ures sivatagi mezok nem csinalnak semmit lepesuk soran
     */
    public void Step(){}
    /**
     * lephet-e ra jatekos
     * @return az ures sivatagi mezore sose fogadhat jatekost
     */
    public Boolean CanAcceptPlayer(){
        return false;
    }
    /**
     * kilistazza a szabotor altal elvegezheto akciokat, az ures sivatagi mezon
     * @param saboteur a szabotor aki elvegzi az akciot
     */
    public void SaboteurOptions(Saboteur saboteur){}
    /**
     * kilistazza a szerelo altal elvegezheto akciokat, az ures sivatagi mezon
     * @param fixer a szerelo aki elvegzi az akciot
     */
    public void FixerOptions(Fixer fixer){}

    //todo
    public Field Update() {
        return this;
    }
}
