import java.util.*;

/**
 * A korok inditasaert es vezerleseert felelos osztaly.
 * Egy kor a jatekosok lepeseivel indul, majd utana “mozdul az ido”,
 * ilyenkor folyik a viz, es a kifolyt vizert a szabotorok, a ciszternaba jutott vizert a szerelok kapnak pontot.
 */
public class ActionHandler {

    /**
     * A parameterkent kapott jatekos korenek iranyitasaert felel.
     * @param p soron levo jatekos
     */
    public void PlayerTurn(Player p){
        while(p.GetActionPoints()<0){
            p.InteractOptions();
        }
    }

    /**
     * Egy teljes kor levezenylese, a jatekosok lepeseit es az ido mulasat is beleertve.
     */
    public void HandleTurn(){
        List<Player> players=Game.Get().GetPlayers();
        for(Player p: players){
            Game.Get().SetActivePlayer(p);
            PlayerTurn(p);
        }
    }

    /**
     * A csohalozatban torteno esemenyek iranyitasaert felel.
     */
    public void WorldTurn(){
        ArrayList<ArrayList<Field>> field = Game.Get().GetMap().GetFields();
        for(int i=field.size()-1; i>-1; i--){
            if(field.get(i).size()!=0) {
                for (int j = field.get(i).size() - 1; j > -1; j--) {
                    field.get(i).get(j).Step();
                }
            }
        }
    }
}
