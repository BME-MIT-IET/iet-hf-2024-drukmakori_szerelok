import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

/**
 * A cso szallitja a vizet a jatekban tovabba ez biztositja az utat a szerelo es a szabotor szamara is.
 * Egy csovon egyszerre csak egy jatekos lehet, azaz nem haladhatnak rajta parhuzamosan.
 * A csonek van kapacitasa, amely megmutatja, hogy a csoben az adott pillanatban van-e viz.
 * A csoben nincsenek elagazasok, ket vegpont kozott halad.
 * A csovet a szabotor jatekosok ki tudjak lyukasztani. A csovet lehet ragadossa es csuszossa tenni.
 * A csovek a ciszternaknal jonnek letre, es onnan flexibilisen bekothetok a jatek tobbi aktiv elemebe.
 */
public class Pipe extends Active{
    /**
     * referencia teszteleshez (nev amit a create fuggvenyben kapott
     */
    private String referenceID;
    public Pipe(String refID){
        SetRemovable(true);
        referenceID=refID;
    }
    public Pipe(){
        SetRemovable(true);
        referenceID= UUID.randomUUID().toString();
    }
    
    /**
     * azt mutatja, hogy meg hany korig nem lehet ujra kilyukasztani
     */
    private int unDestroyable = 0;
    /**
     * azt mutatja, hogy meg hany korig csuszos
     */
    private int slippery = 0;
    /**
     * azt mutatja, hogy meg hany korig ragados
     */
    private int sticky = 0;
    /**
     * jatekos, aki sticky-ve tette a csovet
     */
    private Player madeStickyBy;

    /**
     * @return tesztelesi referencia
     */
    public String GetReferenceID(){return referenceID;}

    /**
     * a cso korvegi lepese, ilyenkor folyik tovabb egy egysegnyi viz a csoben
     */
    public void Step(){
        LeakWater();
        ForwardWater();
        if(slippery > 0)
            slippery--;
        if(unDestroyable > 0)
            unDestroyable--;
        if(sticky > 0)
            sticky--;
    }

    /**
     * megjavitja az elromlott csovet
     */
    public void Fix(){
        SetIsBroken(false);
        Game.Get().GetActivePlayer().DecreaseActionPoints();
        if(PrototypeTester.Get().GetIsRandom()) unDestroyable = new Random().nextInt(3)+1;
        else unDestroyable=3;
    }

    /**
     * eltavolitja a csovet a halozatbol
     * @param f Fixer, aki felveszi
     */
    public void Remove(Fixer f){
        f.DecreaseActionPoints();
        Map map=Game.Get().GetMap();
        map.ReplaceField(this, null);
        f.SetActive(this);
        f.SetHasActive(true);
    }

    /**
     * kifolyatja a vizet
     */
    public void LeakWater(){
        if(GetHasWater() && GetIsBroken()){
            SetHasWater(false);
            Game.Get().InceraseSaboteurPoints();
        }
    }

    /**
     * Vizet tovabbit a kimeneten
     */
    public void ForwardWater(){
        if(GetHasWater() && !GetIsBroken()){
            Field pOut=GetPOut();
            if(pOut!=null){
                boolean accepted=pOut.AcceptWater(this);
                if(accepted){
                    SetHasWater(false);
                }
            }
            else{
                Game.Get().InceraseSaboteurPoints();
            }
        }
    }

    /**
     * cso fogadja a vizet
     * @param f mezo, ahonnan fogadja a vizet
     * @return sikeresen fogadta-e a vizet, vagy sem
     */
    public boolean AcceptWater(Field f){
        if(!GetHasWater()){
            SetPIn(f);
            for(Field field: Game.Get().GetMap().GetNeighbours(this)){
                if(field!=f){
                    SetPOut(field);
                }
            }
            SetHasWater(true);
            return true;
        }
        return false;
    }

    /**
     * Fogadja a ralepo jatekost
     */
    public void AcceptPlayer(){
        Player player = Game.Get().GetActivePlayer();
        player.DecreaseActionPoints();
        if(slippery == 0) {
            AddPlayer(player);
        }
        else{
            List<Field> neighbours = Game.Get().GetMap().GetNeighbours(this);
            List<Field> steppableNeighbours = new ArrayList<Field>();
            for(Field neighbour: neighbours) {
                if (neighbour.CanAcceptPlayer())
                    steppableNeighbours.add(neighbour);
            }
            if(steppableNeighbours.size() == 1)
                steppableNeighbours.get(0).AddPlayer(player);
            else if(steppableNeighbours.size() == 2)
                steppableNeighbours.get(new Random().nextInt(2)).AddPlayer(player);
            else
                AddPlayer(player);
        }
    }

    /**
     * visszaadja, hogy tud-e a cso jatekost fogadni
     * @return true, ha 0 jatekos all rajta, false ha 1
     */
    public Boolean CanAcceptPlayer(){
        return GetPlayer().size()==0;
    }

    /**
     * beallitja slippery erteket a parameterul kapottra
     * @param slip slippery uj erteke
     */
    public void SetSlippery(int slip) {
        slippery = slip;
    }

    /**
     * visszadja slippery erteket
     * @return hany korig slippery meg
     */
    public int GetSlippery() {
        return slippery;
    }

    /**
     * beallitja sticky erteket a parameterul kapottra
     * @param sticky sticky uj erteke
     */
    public void SetSticky(int sticky) {
        this.sticky = sticky;
        madeStickyBy = Game.Get().GetActivePlayer();
    }
    /**
     * visszadja sticky erteket
     * @return hany korig sticky meg
     */
    public int GetSticky() {
        return sticky;
    }
    /**
     * visszadja unDestroyable erteket
     * @return hany korig unDestroyable meg
     */
    public int GetUnDestroyable() {
        return unDestroyable;
    }

    /**
     * kilistazza a szabotor altal elvegezheto akciokat
     * @param saboteur szabotor, aki vegzi az akciokat
     */
    public void SaboteurOptions(Saboteur saboteur){
        saboteur.ClearOptions();
        List<Field> neighbours = Game.Get().GetMap().GetNeighbours(this);
        List<Field> steppableNeighbours = new ArrayList<Field>();
        for(Field neighbour: neighbours){
            if(neighbour.CanAcceptPlayer()){
                steppableNeighbours.add(neighbour);
            }
        }
        if((sticky == 0 || madeStickyBy == saboteur) && steppableNeighbours.size() != 0){
            saboteur.AddOption("move");
        }
        if(sticky == 0 && slippery == 0){
            saboteur.AddOption("make sticky");
            saboteur.AddOption("make slippery");
        }
        if(!GetIsBroken() && unDestroyable == 0){
            saboteur.AddOption("sabotage pipe");
        }
    }

    /**
     * kilistazza a szerelo altal elvegezheto akciokat
     * @param fixer szerelo, aki vegzi az akciokat
     */
    public void FixerOptions(Fixer fixer){
        fixer.ClearOptions();
        List<Field> neighbours = Game.Get().GetMap().GetNeighbours(this);
        List<Field> steppableNeighbours = new ArrayList<Field>();
        List<Field> removableNeighbours = new ArrayList<Field>();
        for(Field neighbour: neighbours){
            if(neighbour.CanAcceptPlayer())
                steppableNeighbours.add(neighbour);
            if(neighbour.GetRemovable())
                removableNeighbours.add(neighbour);
        }
        if((sticky == 0 || madeStickyBy == fixer) && steppableNeighbours.size() != 0)
            fixer.AddOption("move");
        if(!fixer.GetHasActive() && removableNeighbours.size() != 0)
            fixer.AddOption("remove pipe");
        if(fixer.GetHasActive() && removableNeighbours.size() != 0)
            fixer.AddOption("place active");
        if(GetIsBroken())
            fixer.AddOption("fix");
        if(sticky == 0 && slippery == 0)
            fixer.AddOption("make sticky");
        if(!GetIsBroken() && unDestroyable == 0)
            fixer.AddOption("sabotage pipe");
    }
    /**
     * beallitja az elem iranyat
     * @param in be, vagy kimenetkent allitjuk be az elemet
     */
    public void SetDirection(boolean in, Field a){
        if(in){
            Field pin=GetPIn();
            Field pout=GetPOut();
            SetPIn(pout);
            SetPIn(pin);
            if(pin!=null){
                pin.SetDirection(true, this);
            }
        }
        if(!in){
            Field pin=GetPIn();
            Field pout=GetPOut();
            SetPIn(pout);
            SetPIn(pin);
            if(pout!=null){
                pout.SetDirection(false, this);
            }
        }
    }


    /**
     * A kor vegen a cso allapotatol fuggoen tovabbitja, vagy ereszti a vizet
     * @return
     */
    public Field Update() {
        Pipe next = new Pipe();
        next.SetPIn(GetPIn());
        next.SetPOut(GetPOut());
        if(!GetIsBroken() && GetPIn().GetHasWater()){
            next.GetPIn().SetHasWater(false);
            next.SetHasWater(true);
        }else if(GetIsBroken() && GetPIn().GetHasWater()){
            next.setHasWater(false);
            next.GetPIn().SetHasWater(false);
            Game.Get().InceraseSaboteurPoints();
        }else if(GetIsBroken() && !GetPIn().GetHasWater()){
            next.setHasWater(false);
        }else if(!GetPIn().GetHasWater() || GetHasWater() && GetPIn().GetHasWater()){
            next = this;
        }
        return next;
    }

}
