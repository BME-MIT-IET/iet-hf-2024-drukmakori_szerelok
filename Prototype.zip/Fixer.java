import java.util.UUID;

/**
 * A szerelo jatekos kepes mozogni a csovek halozatan,
 * kepes a ciszternanal letrejott csovek pumpaba kotesere es kepes pumpat elhelyezni a sivatagban.
 * At tudja allitani a pumpa melyik bemeneterol melyik kimenetere pumpalja a vizet
 * es meg is tudja javitani a pumpat, ha az elromlott.
 */
public class Fixer extends Player{
    /**
     * referencia teszteleshez (nev amit a create fuggvenyben kapott
     */
    private String referenceID;

    public Fixer(String refID){
        referenceID=refID;
    }
    public Fixer(){
        referenceID= UUID.randomUUID().toString();
    }
    /**
     * szerelonel levo aktiv elem
     */
    private Active active;
    /**
     * van-e nala aktiv elem
     */
    private boolean hasActive;

    /**
     * @return tesztelesi referencia
     */
    public String GetReferenceID(){return referenceID;}

    /**
     * a parameterkent kapott mezot megjavitja
     * @param active a megjavitando
     */
    public void Fix(Active active) {
        active.Fix();
    }
    /**
     * felvesz egy lent levo csovet
     * @param p a felvett cso
     */
    public void RemoveActivePipe(Pipe p){
        p.Remove(this);
    }
    /**
     * maga ele lerakja a nala levo csovet vagy a pumpat
     * @param f a mezo amit kicserel
     */
    public void Place(Field f){
        f.ReplaceByFixer(this, GetField());
    }
    /**
     * felvesz egy pumpat a ciszternabol
     * @param tank taroló
     */
    public void CarryPump(Tank tank){
        tank.GivePump(this);
    }
    /**
     * felvesz egy csovet a ciszternabol
     * @param tank tarolo
     */
    public void CarryPipe(Tank tank){
        tank.GivePipe(this);
    }
    /**
     * beallitja a megfelelo aktiv elemet, amely a jatekosnal van
     * @param a aktiv elem a jatekosnal
     */
    public void SetActive(Active a){
        active = a;
    }
    /**
     * meghivja azon mezo FixerOptions metodusat, amin all
     */
    public void InteractOptions(){
        GetField().FixerOptions(this);
    }
    /**
     * visszadja a nala levo aktiv elemet
     * @return nala levo aktiv elem
     */
    public Active GetActive(){
        return active;
    }
    /**
     * visszadja, hogy van-e nala aktiv elem
     * @return hasActive erteke
     */
    public boolean GetHasActive(){
        return hasActive;
    }
    /**
     * beallitja, hogy van-e nala aktiv elem
     * @param b hasActive uj erteke
     */
    public void SetHasActive(boolean b){
        hasActive = b;
    }
}
