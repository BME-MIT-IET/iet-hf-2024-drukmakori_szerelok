import java.io.*;
import java.util.ArrayList;

/**
 * A tesztelo segedprogram innen indul el, beolvassa az input fileokat, majd tovabbadja a tesztfuggvenyeknek,
 * majd a visszakapott outputot osszeveti az elvart kimenettel, ezzel ellenorizve, hogy valoban az tortent-e a
 * teszt lefutasa soran, amit elvarunk.
 */
public class Main{

    public static void main(String[] args) throws IOException {
        PrototypeTester pt = new PrototypeTester();
        ArrayList<String> li = TestNameReader();
        int i=0; int success=0;
        for(i=0;i<43;i++){
            String returnString = pt.Test(TestReader((i+1)+".txt"));

            boolean b=inAndExpectedOutCompare(returnString,(i+1)+"out.txt");
            if(b) {
                System.out.println((i+1)+". "+li.get(i)+": SUCCESS");
                success++;
            }
            else System.out.println((i+1)+". "+li.get(i)+": FAIL");
        }
        System.out.println("Success rate: "+success+"/"+(i)+"\n\n");

        CustomTester(pt);

    }

    /**
     * A CustomTester segitsegevel futtathatjuk a sajat tesztjeinket. A fuggveny bekeri a bemeneti file nevet,
     * majd a tesztek lefuttatasa utan kiirja a program kimenenetet az out.txt fileba, igy tudjuk ellenorizni,
     * hogy a megfelelo kimenet erkezett-e.
     * @param pt a tesztelo osztaly ami a teszteket elvegzi
     * @throws IOException hibas input file eseten
     */
    public static void CustomTester(PrototypeTester pt) throws IOException{
        System.out.println("Add a filename (without .txt): ");
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String in=br.readLine();
        String returnString = pt.Test(TestReader(in+".txt"));
        //if(!returnString.equals("")){
            PrintWriter pw = new PrintWriter(new OutputStreamWriter( new FileOutputStream(in+"out.txt")));
            System.out.println(in+"out.txt file is written");
            pw.println(returnString);
            pw.close();
        //}
        br.close();
    }

    /**
     * A TestReader fuggveny a kapott tesztbemenet file tartalamt dologzza fel,
     * soronkent szetvalasztja es String[] tombokbe rakja a sorokat, ezzel feldolgozhatova teszi a
     * bemeneti file-t.
     * @param filename a bemeneti .txt file amit fel kell dolgozni
     * @return soronkent String[] tombokbe rendezve az input file tartalma
     */
    public static ArrayList<String[]> TestReader(String filename){
        BufferedReader br = null;
        try {
            br = new BufferedReader(new InputStreamReader(new FileInputStream(filename)));
        } catch (FileNotFoundException e){ System.out.println("There is not a file with such name: "+filename); }
        ArrayList<String[]> list = new ArrayList<>();
        while (true) {
            String line = "";
            String[] command;
            try {
                line = br != null ? br.readLine() : null;
                if(line!=null) {
                    command=line.split(" ");
                    list.add(command);
                }
            } catch (IOException ignored) {}
            if(line==null) break;
        }
        try {
            if(br!=null) br.close();
        } catch (IOException ignored) { }
        return list;
    }

    /**
     * Az outPutReader fuggveny beolvas egy elvart kimenet .txt file-t es visszaadja annak tartalmat egy
     * String formajaban, ezt hasonlitjuk majd ossze a program kimenetevel.
     * @param path A beolvasando elvart kimenetet tartalmazo file.
     * @return Egy String, a beolvasott file szovegevel.
     * @throws IOException hibas parameter eseten hibat dob
     */
    public static String outPutReader(String path) throws IOException{
        BufferedReader br = null;
        try {
            br = new BufferedReader(new InputStreamReader(new FileInputStream(path)));
        } catch (FileNotFoundException e){ System.out.println("There is not a file with such name: "+path); }
        String fileContent="";
        String line = br.readLine();
        while (line != null) {
            fileContent += line + "\n";
            line = br.readLine();
        }
        try {
            if(br!=null) br.close();
        } catch (IOException e) { }
        return fileContent;
    }

    /**
     * Osszehasonlito fuggveny a program kimenete es az elvart kimenet file kozott
     * @param stringToCompare itt adjuk meg a tesztprogram valaszat
     * @param outputFileName itt adjuk meg az elvart kimenet .txt file-t
     * @return ha egyezik a ket output, akkor igazat, kulonben hamisat adunk vissza
     * @throws IOException hibas elvart kimenet parameter eseten hibat dob
     */
    public static boolean inAndExpectedOutCompare(String stringToCompare,String outputFileName)throws IOException{
        String out=outPutReader(outputFileName);
        return out.equals(stringToCompare);
    }

    /**
     * A TestNameReader fuggveny kiolvassa a testnames.txt file tartalmat, amelyben a futtatott tesztek
     * nevei szerepelnek, majd visszaadja azt.
     * @return A tesztek nevei ArrayList<String> listaban
     */
    public static ArrayList<String> TestNameReader(){
        BufferedReader br = null;
        try {
            br = new BufferedReader(new InputStreamReader(new FileInputStream("testnames.txt")));
        } catch (FileNotFoundException e){ System.out.println("There is not a file with such name: testnames.txt"); }
        ArrayList<String> list = new ArrayList<>();
        while (true) {
            String line = "";
            try {
                line = br != null ? br.readLine() : null;
                if(line!=null) {
                    list.add(line);
                }
            } catch (IOException ignored) {}
            if(line==null) break;
        }
        try {
            if (br != null) {
                br.close();
            }
        } catch (IOException ignored) { }
        return list;
    }

}