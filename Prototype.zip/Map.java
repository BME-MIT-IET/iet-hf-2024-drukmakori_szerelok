import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * A palyan levo dolgok poziciojaert es tarolasaert felelos osztaly,
 * amely dinamikusan frissul, ahogy epul a csohalozat.
 */
public class Map {
    /**
     * referencia teszteleshez (nev amit a create fuggvenyben kapott)
     */
    private String referenceID;
    /**
     * osszes mezo
     */
    private ArrayList<ArrayList<Field>> map;
    private List<Field> sor;
    private static final int maxSize = 25;


    /**
     * osszes mezo
     */
    public Map(String refID) {
        map = new ArrayList<>();
        for (int i = 0; i < maxSize; i++) {
            ArrayList<Field> fields = new ArrayList<>();
            map.add(fields);
        }
        referenceID = refID;
    }

    /**
     * konstruktor
     */
    public Map() {
        map = new ArrayList<>();
        for (int i = 0; i < maxSize; i++) {
            ArrayList<Field> fields = new ArrayList<>();
            map.add(fields);
        }
        referenceID = UUID.randomUUID().toString();
    }

    /**
     * kicserel egy mezot egy masikkal
     * @param target regi mezo
     * @param source uj mezo
     */
    public void ReplaceField(Field target, Field source){
        target = source;
    }

    /**
     * visszaadja a palyat
     * @return a palya
     */
    public ArrayList<ArrayList<Field>> GetFields(){
        return map;
    }

    /**
     * visszaadja egy mezohoz tartozo szomszedokat
     * @param f az adott mezo
     * @return f szomszedjai
     */
    public List<Field> GetNeighbours(Field f){
        List<Field> a = new ArrayList<>();
        int j = 0,i = 0;
        boolean found = false;
        for (i = 0; i < map.size() && !found; i++){
            for(j = 0; j < map.get(i).size() && !found; j++){
                if(f == map.get(i).get(j)) { found = true;}
            }
        }
        i--; j--;

        try{
            if(j != map.get(i).size())
                a.add(map.get(i).get(j+1));
        }catch(Exception e){

        }
        try{
            if(j != 0)
                a.add(map.get(i).get(j-1));
        }catch(Exception e){

        }
        try{
            if(i != map.size())
                a.add(map.get(i+1).get(j));
        }catch(Exception e){

        }
        try{
            if(i != 0)
                a.add(map.get(i-1).get(j));
        }catch(Exception e){

        }

        return a;
    }


    /**
     * Elvegzi a terkep frissiteset mezonkent
     */
    public void UpdateMap(){
        ArrayList<ArrayList<Field>> next = new ArrayList<>();
        for(ArrayList<Field> row : map){
            for(Field field : row){
                row.add(field.Update());
            }
        }
        map = next;
    }

    /**
     * hozzadja a kapott mezot a tablahoz
     * @param f1
     */
    public void addField(Field f1){
        int x=0;
        int y=0;
        for(int i=0;i<map.size() && i<maxSize;i++){
            for(int j=0;j<map.get(i).size() && i<maxSize;j++){
                x=i;
                y=j+1;
            }
        }
        map.get(x).add(y,f1);
    }
    /**
     * visszaadja a parameterul kapott ID-val rendelkezo mezot
     * @param refID keresett mezo ID-ja
     * @return keresett mezo
     */
    public Field searchField(String refID){
        Field temp=null;
        for(int i=0;i<map.size() && i<maxSize;i++){
            for(int j=0;j<map.get(i).size() && i<maxSize;j++){
                if(map.get(i).get(j).GetReferenceID().equals(refID)){
                    temp=map.get(i).get(j);
                }
            }
        }
        return temp;
    }

}
